<?php
/**
 * MyCustomJournal setup
 *
 * @package  MyCustomJournal
 * @since    1.0.0
 */

final class MyCustomJournal {

  function __construct() {
    // init = initialization
    add_action( 'init', array( $this, 'custom_post_type') );

    $this->plugin = plugin_basename( __FILE__ );
  }

  function register() {
    // on the front end
    add_action( 'wp_enqueue_scripts', array( $this, 'enqueue') );
    // on the back end
    add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin') );

    add_action( 'admin_menu', array( $this, 'add_admin_pages') );

    add_filter( "plugin_action_links_$this->plugin", array( $this, 'settings_link' ) );

    add_action( 'wp', array( $this, 'get_pages') );

    add_filter( 'single_template',  array( $this, 'get_custom_post_type_template' ) );


  }

  public function settings_link( $links ){
    // add settings link to array
    $settings_link = '<a href="admin.php?page=mycustomjournal_plugin">Settings</a>';
    array_push( $links, $settings_link );
    return $links;
  }

  public function add_admin_pages() {
    // page title, menu title, capability users, menu slug, callback function, icon, position in sidebar
    add_menu_page( 'MyCustomJournal Plugin', 'MyCustomJournal', 'manage_options', 'mycustomjournal_plugin', array( $this, 'admin_index' ), 'dashicons-store', 200  );
  }

  public function admin_index() {
    // require template
    require_once plugin_dir_path( __FILE__ ) . '../templates/admin.php';

  }

  function activate() {
    // genereated a custom post type
    // flush rewrite rules
    flush_rewrite_rules();
  }

  function deactivate() {
    // flush rewrite rules
    flush_rewrite_rules();
  }

  function custom_post_type(){
    	register_taxonomy('template-category', 'template', array( 'label' => 'Template Category', 'hierarchical' => true, ) );
      register_post_type( 'template', ['public' => true, 'label' => 'Templates', 'taxonomies' => array( 'template-category' ), 'supports' => array( 'title', 'thumbnail', 'editor' )] );
  }

  function enqueue() {
    // enqueue all our scripts
    wp_enqueue_style( 'mypluginstyle', plugins_url( '../assets/style.css', __FILE__ ) );
    wp_enqueue_style( 'mypluginscript', plugins_url( '../assets/script.js', __FILE__ ) );
  }

  function enqueue_admin() {
    // enqueue all our scripts
    wp_enqueue_style( 'mypluginstyle', plugins_url( '../assets/style-admin.css', __FILE__ ) );
    wp_enqueue_style( 'mypluginscript', plugins_url( '../assets/script-admin.js', __FILE__ ) );
  }


  function get_pages()  {
  	if(is_page('select-type')){
  		$dir = plugin_dir_path( __FILE__ );
  		include($dir."../templates/select-type.php");
  		die();
  	}
  }

  function get_custom_post_type_template( $template ){
    global $post;
    if ($post->post_type == 'template') {
         $template = plugin_dir_path( __FILE__ ).'../templates/single-template.php';
    }
    return $template;
  }

  // function get_custom_post_type_template( $archive_template ) {
  //    global $post;
  //
  //    if ( is_post_type_archive ( 'template' ) ) {
  //         $archive_template = dirname( __FILE__ ) . '../templates/archive-template.php';
  //    }
  //    return $archive_template;
  //  }


}
