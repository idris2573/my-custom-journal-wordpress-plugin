<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Select Type</title>
<?php get_header(); ?>


</head>
<body>
<h1>Select Type</h1>

<?php
$customPostTaxonomies = get_object_taxonomies('template');

if(count($customPostTaxonomies) > 0)
{
     foreach($customPostTaxonomies as $tax)
     {
	     $args = array(
         	  'orderby' => 'name',
	          'show_count' => 0,
        	  'pad_counts' => 0,
	          'hierarchical' => 1,
        	  'taxonomy' => $tax,
        	  'title_li' => '',
            'hide_empty' => 0
        	);

	     wp_list_categories( $args );
     }
}
 ?>

<?php get_footer(); ?>
</body>
</html>
