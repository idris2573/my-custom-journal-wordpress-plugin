<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<title>Customize Product</title>
<?php get_header(); ?>

</head>
<body>

<?php
  $categories = wp_get_post_terms($post->ID, 'template-category', array("fields" => "names"));
  $categories = array_reverse($categories);

  // get product category id from template category name
  $template_cat = $categories[1]; //child category
  $category = get_term_by( 'slug', $template_cat, 'product_cat' );
  $cat_id = $category->term_id;
?>

<h1>Customize Product</h1>


<?php echo do_shortcode("[fpd]"); ?>

<!-- <?php echo do_shortcode("[fpd_form]"); ?> -->

<div class="mt-5 d-flex">
  <h3 class="font-weight-bold mr-5">Base Price: $50</h3>
  <h3 class="font-weight-bold mr-5">Profit: $25</h3>
  <h3 class="font-weight-bold mr-5">Category: <?php echo implode(" > ",$categories); ?> </h3>
</div>


<?php

//CREATE NEW PRODUCT
  if(sizeof($_GET) != 0){

    print_r($_GET);

    // check if product url is empty
    $slug;
    if(!empty($_GET['product-url'])){
      $slug = $_GET['product-url'];
    }else{
      $slug = $_GET['product-name'];

    }

    //get image from image folder
    $time = get_the_time('Y/m/d');
    $image = $_GET['product-image'];
    $image_folder = get_home_url()."/wp-content/uploads/fancy_products_uploads/$time/$image" ;
    echo $image_folder;

    // info to add to product
    $data = [

        'name' => $_GET['product-name'],
        'description' => $_GET['product-description'],
        'regular_price' => $_GET['your-price'],
        'slug' => $slug,
        'status' => 'pending',
        'images' => [
            [
                'src' => $image_folder,
                'position' => 0
            ]
          ],
          'categories' => [
            [
                'id' => $cat_id
            ]
          ]
        // 'sale_price'  => '8'

    ];
    $request = new WP_REST_Request( 'POST' );
    $request->set_body_params( $data );
    $products_controller = new WC_REST_Products_Controller;
    $response = $products_controller->create_item( $request );

    // get the product id from response
    $response_string = print_r($response, true);
    $id_pos = strpos($response_string, '[id] =>');
    $id = substr($response_string, $id_pos);
    $name_pos = strpos($id, '[name] =>');
    $id = substr($id, 0, $name_pos);
    $id = str_replace('[id] =>','',$id);

    // echo 'current user : ' . get_current_user_id();
    $author_id = get_current_user_id();


    // Access the database via SQL and use author id to get vendor id
    global $wpdb;
    $vendor_id = $wpdb->get_var( "SELECT term_id FROM wp_termmeta WHERE meta_key = 'vendor_data' AND meta_value LIKE '%i:$author_id;%'" );
    $wpdb->query( "INSERT INTO wp_term_relationships(object_id, term_taxonomy_id, term_order) VALUES($id, $vendor_id, 0)" );


    ?>
    <h4 class="mb-5 font-weight-bold">Your product is now in review.</h4>


<?php
  } else {
?>



<div class="my-5" method="post">
  <form class=" text-center" onSubmit="imageLink();">

      <div class="input-group mb-2">
        <div class="input-group-prepend">
          <div class="input-group-text">$</div>
        </div>
        <input type="number" class="form-control" id="your-price" name="your-price"  min="50.00" step="0.01" max="2500" placeholder="Your Price" required="required">
      </div>

    <div class="form-group">
      <input type="text" class="form-control" id="product-name" name="product-name" placeholder="Product Name" required="required">
    </div>

    <div class="form-group">
       <textarea class="form-control" id="product-description" name="product-description" rows="3" placeholder="Product description" required="required"></textarea>
     </div>

     <div class="form-group">
       <input type="text" class="form-control" id="product-tags" name="product-tags" placeholder="Product Tags (seperated with commas)">
     </div>

     <div class="form-group">
       <input type="text" class="form-control" id="product-url" name="product-url"placeholder="Product Url">
     </div>

     <div class="form-check mb-4 text-left">
       <input class="form-check-input" type="checkbox" value="true" id="terms-service" name="terms-service" required="required">
       <label class="form-check-label" for="defaultCheck1">
         Do you accept the <a href="#">Terms of service</a>
       </label>
     </div>

     <input type="hidden" id="product-image" name="product-image" value="" />

    <button type="submit" id="submit" class="btn btn-primary" value="submit" name="submit">Sign in</button>

  </form>
</div>

<?php
  }
?>


<script>
function imageLink() {
  var image = document.getElementsByClassName("fpd-item")[5].getAttribute('data-title');
  document.getElementById('product-image').value = image;
}
</script>



<?php get_footer(); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
